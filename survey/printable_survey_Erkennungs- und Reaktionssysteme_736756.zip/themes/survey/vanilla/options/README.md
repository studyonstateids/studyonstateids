![LimeSurvey Logo](https://account.limesurvey.org/images/logos/logo_main.png)
# Survey Themes Custom options

Since LimeSurvey 3, Theme providers can now add their own options in a template.
The files options.twig and options.js will be used to render the theme's option page inside the Admin Interface.
For Core Theme, this option page is very basic and simple. So, please, if you're a Theme Provider, try to create your own option page with its own look and feels.
