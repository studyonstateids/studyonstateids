![LimeSurvey Logo](https://account.limesurvey.org/images/logos/logo_main.png)
# LimeSurvey Bootstrap Vanilla Survey Theme

## About
A clean and simple base that can be used by developers to create their own Bootstrap based theme.
